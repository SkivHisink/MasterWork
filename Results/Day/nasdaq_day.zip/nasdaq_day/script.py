import multiprocessing
import subprocess
import os
import sys

def generate_lists():
    lists = []
    p_max = 11
    d_max = 11
    q_max = 11
    max_iteration_num = int(p_max * q_max * d_max / (os.cpu_count() - 1))
    iteration_num = 0
    lists.append([0,0,0, max_iteration_num])
    for i in range(p_max):
        for j in range(d_max):
            for k in range(q_max):
                iteration_num += 1
                if iteration_num % max_iteration_num  == 0:
                    iteration_num = 0
                    lists.append([i, j, k, max_iteration_num])
    lists[len(lists) - 1][3] += (p_max * q_max * d_max - max_iteration_num * os.cpu_count())
    return lists

def run_script(arg):
    print('module name:', __name__)
    print('parent process:', os.getppid())
    print('process id:', os.getpid())
    cmd = f'{sys.executable} ARIMATest.py {arg}'
    result = subprocess.run(cmd, capture_output = True, text = True, encoding='utf-8')

    # Получение вывода процесса
    stdout = result.stdout
    stderr = result.stderr
    
    # Вывод результатов
    print(f"{os.getpid()}: {stdout}")
    
    if stderr:
        print(f"{os.getpid()}:{stderr}")

    return result.returncode

if __name__ == '__main__':
    num_processes = multiprocessing.cpu_count()  # количество логических процессов
    result_lists = generate_lists()
    argument = "test"  # аргумент, который нужно передать
    processes = []
    for elem in result_lists:  # num_processes
        p = multiprocessing.Process(target = run_script, 
                                    args = (f'{elem[0]} {elem[1]} {elem[2]} {elem[3]}',))
        processes.append(p)
        p.start()
    for p in processes:
        p.join()
        if p.exitcode != 0:
            print(f"Process {p.pid} exited with code {p.exitcode}")