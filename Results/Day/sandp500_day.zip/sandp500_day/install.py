import subprocess
import sys

def install(package):
    subprocess.check_call([sys.executable, "-m", "pip", "install", package])

# Список библиотек и их версий
required_packages = [
    "statsmodels==0.13.2",
    "pandas==1.4.2",
    "numpy==1.21.5"
]

# Установка библиотек
for package in required_packages:
    try:
        install(package)
        print(f"Установлена библиотека: {package}")
    except subprocess.CalledProcessError as e:
        print(f"Ошибка при установке библиотеки: {package}")
        print(f"Ошибка: {str(e)}")